package texteditor;

import java.util.Optional;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

// Die neue Klasse F�r Aufgabe 2. Erweitert Alert um im Konstruktor zus�tzliche Felder zu setzen und die "anzeigen" Methode
public class DialogUniversell extends Alert {

	/**
	 * Konstruktor setzt �bliche Felder von der Klasse Alert sowie den Text und Header.
	 * @param title Titel des Dialogs
	 * @param header Header/Frage des Dialogs
	 * @param content Content/Frage des Dialogs
	 */
	public DialogUniversell(String title, String header, String content) {
		super(AlertType.CONFIRMATION, content, ButtonType.YES, ButtonType.NO);
		setHeaderText(header);
		setTitle(title);
	}
	
	/**
	 * neue "showAndWait" Methode zum anzeigen des Dialogs und stellen der Frage
	 * @return Gibt einen boolean Wert zur�ck: True, wenn mit "Ja" beantowrtet wurde, False sonst
	 */
	public boolean anzeigen() {
        showAndWait();
        return getResult() == ButtonType.YES;
	}
	
}
